export class Answer {
    content: string
    details: String
    like: number
    questionId: string
    userId: string    
}

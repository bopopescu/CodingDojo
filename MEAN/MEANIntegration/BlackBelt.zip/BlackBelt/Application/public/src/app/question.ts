export class Question {
    title: string
    description: string
    answers: number = 0
    userId: string
    
}

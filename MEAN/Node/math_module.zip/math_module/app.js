var mathlib = require('./mathlib')();
mathlib.add(5,6);
mathlib.multiply(5,6);
mathlib.square(5);
mathlib.random(5,10);
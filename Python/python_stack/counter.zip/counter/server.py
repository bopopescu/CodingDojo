from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)

app.secret_key = 'ThisIsSecret'



#session['counter'] = 0
def session_count():
    try:
        session['count'] += 1
    except KeyError:
        session['count'] = 1
    return session['count']


@app.route('/')

def index():
    #get = session_count()
    return render_template("index.html", counter = session_count())

@app.route('/incrementbyTwo', methods=['POST'])
def incrementbyTwo():
    session['count'] += 1
    return redirect('/')



@app.route('/reset', methods=['POST'])
def reset():
    session['count'] = 0
    return redirect('/')


app.run(debug=True) #run our server
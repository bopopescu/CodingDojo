from __future__ import unicode_literals

from django.db import models

import re

from django.contrib import messages

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
FIRSTNAME_REGEX = re.compile(r'^[a-zA-Z]')
LASTNAME_REGEX = re.compile(r'^[a-zA-Z]')

# Create your models here.

class UserManager(models.Manager):
    # def login(self, emailforlogin, passwordforlogin):
    #
    #     print sdsdsds
    #     return
    def register(self, email,  first_name, last_name, password, passwordconfirmation):
        validations = []
        email_match = True
        firstname_match = True
        lastname_match = True
        password_length = True
        password_match = True
        no_same_email = True
        if len(email) < 1 and not EMAIL_REGEX.match(email):
            email_match = False
        try:
            checkforsameemail = User.userManager.get(email=email)
            no_same_email = False
        except:
            no_same_email = True
        if len(first_name) < 2 and not FIRSTNAME_REGEX.match(first_name):
            firstname_match = False
        if len(last_name) < 2 and not LASTNAME_REGEX.match(last_name):
            lastname_match = False
        if len(password) < 8 and len(passwordconfirmation) < 1:
            password_length = False
        if password != passwordconfirmation:
            password_match = False


        validations = [email_match, firstname_match, lastname_match, password_length, password_match, no_same_email]

        return validations
    def login(self, emailforlogin, passwordforlogin):
        validationsforlogin = []
        valemail = True
        valpassword = True
        successforemail = True
        successforpassword = True
        if len(emailforlogin) < 1:
            valemail = False
        if len(passwordforlogin) < 1:
            valpassword = False

        try:
            User.userManager.get(emailforlogin)
        except:
            successforemail = False

        try:
            getusernameforlogin = User.userManager.get(emailforlogin)
            print getusernameforlogin.password
            print passwordforlogin
            if getusernameforlogin.password != passwordforlogin:
                messages.error(request, "Incorrect password!")
                return redirect('/')
            global user_name
            user_name = getusernameforlogin.first_name
        except:
            successforpassword = False

        validationsforlogin = [valemail, valpassword, successforpassword, successforemail]

        return validationsforlogin

class User(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.CharField(max_length=200)
    password = models.CharField(max_length=100)
    created_at = models.DateField(auto_now_add=True)
    updated_at = models.DateField(auto_now_add=True)
    userManager = UserManager();

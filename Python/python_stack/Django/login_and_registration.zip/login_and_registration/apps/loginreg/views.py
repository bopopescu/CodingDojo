from django.shortcuts import render, redirect

# Create your views here.

import re

from django.contrib import messages

from .models import User

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
FIRSTNAME_REGEX = re.compile(r'^[a-zA-Z]')
LASTNAME_REGEX = re.compile(r'^[a-zA-Z]')

user_name = ""

def index(request):
    context = {
        "users": User.userManager.all()
    }
    print User.userManager.all()
    users = User.userManager.all()
    for user in users:
        print user.email
        print user.password
    return render(request, 'loginreg/index.html')
#
def login(request):
    validations_for_login = User.userManager.login(request.POST['emailforlogin'], request.POST['passwordforlogin'])
    success = True
    if not validations_for_login[3]:
        messages.error(request, "Opps! Not in our database! Register!")
        return redirect('/')
    if not validations_for_login[0]:
        messages.error(request, "Email must not be empty or must have more than 2 characters!")
        success = False
    if not validations_for_login[1]:
        messages.error(request, "Password must not be empty or must have more than 2 characters!")
        success = False
    if not validations_for_login[2]:
        messages.error(request, "Password is wrong!")
        success = False

    if success:
        return redirect('/success')
    else:
        return redirect('/')


def toregister(request):
    values_of_validations = User.userManager.register(request.POST['email'], request.POST['first_name'],request.POST['last_name'], request.POST['password'], request.POST['passwordconfirm'])
    success = True
    if not values_of_validations[5]:
        messages.error(request,"Opps! Looks like this email already exists in our database!")
        success = False
    else:
        if not values_of_validations[0]:
            messages.error(request, "Email must not be empty or must be in good format -> asdf@mail.com!")
            success = False
        if not values_of_validations[1]:
            messages.error(request, "Firstname must not be empty or must only have letters!")
            success = False
        if not values_of_validations[2]:
            messages.error(request, "Last Name must not be empty or must only have letters!")
            success = False
        if not values_of_validations[3]:
            messages.error(request, "Password and password confirmation must not be empty!")
            success = False
        if not values_of_validations[4]:
            messages.error(request, "Password and password confirmation must match!")
            success = False


    if success:
        thisuser = User.userManager.create(email=request.POST['email'], first_name=request.POST['first_name'], last_name=request.POST['last_name'], password=request.POST['password'])
        global user_name
        user_name = thisuser.first_name
        return redirect('/success')
    else:
        messages.error(request, "Error!")
        return redirect('/')

def success(request):
    global user_name
    context = {
        "user_name": user_name
    }
    return render(request, 'loginreg/success.html', context)






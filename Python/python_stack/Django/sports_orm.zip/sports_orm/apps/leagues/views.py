from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
		"all_baseball_leagues": League.objects.filter(sport="Baseball"),
		"all_women_leagues": League.objects.filter(name__contains="Womens"),
		"hockey_leagues": League.objects.filter(name__contains="Hockey"),
		"no_football": League.objects.exclude(name__contains="Football"),
		"conf_name": League.objects.filter(name__contains="Conference"),
		"atlantic_region": League.objects.filter(name__contains="Atlantic"),
		"dallas_team": Team.objects.filter(location__contains="Dallas"),
		"raptors_team": Team.objects.filter(team_name__contains="Raptors"),
		"city_team": Team.objects.filter(location__contains="City"),
		"T_team": Team.objects.filter(team_name__startswith="T"),
		"all_teams_location": Team.objects.order_by('location'),
		"all_teams_name_reverse": Team.objects.order_by('team_name').reverse(),
		"last_name_cooper": Player.objects.filter(last_name__contains="Cooper"),
		"first_name_joshua": Player.objects.filter(first_name__contains="Joshua"),
		"cooper_no_joshua": Player.objects.filter(last_name__contains="Cooper").exclude(first_name__contains="Joshua"),
		"alexander_or_wyatt": Player.objects.filter(first_name__contains="Alexander")|Player.objects.filter(first_name__contains="Wyatt")


	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
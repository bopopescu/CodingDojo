from django.shortcuts import render

# Create your views here.
def index(request):
    print "index"
    return render(request, 'myportfolio/index.html')

def testimonials(request):
    print "test work"
    return render(request, 'myportfolio/testimonials.html')
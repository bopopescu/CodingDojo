from django.shortcuts import render, redirect

from .models import Post

# Create your views here.
def index(request):
    allpost = Post.objects.all()
    context = {
        "allpost": allpost
    }
    return render(request, 'notes/index.html', context)

def addnotes(request):
    if request.method == "POST":
        get = Post.objects.create(content = request.POST['content'])
    return redirect('/')

from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Count

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
		# "all_baseball_leagues": League.objects.filter(sport="Baseball"),
		# "all_women_leagues": League.objects.filter(name__contains="Womens"),
		# "hockey_leagues": League.objects.filter(name__contains="Hockey"),
		# "no_football": League.objects.exclude(name__contains="Football"),
		# "conf_name": League.objects.filter(name__contains="Conference"),
		# "atlantic_region": League.objects.filter(name__contains="Atlantic"),
		# "dallas_team": Team.objects.filter(location__contains="Dallas"),
		# "raptors_team": Team.objects.filter(team_name__contains="Raptors"),
		# "city_team": Team.objects.filter(location__contains="City"),
		# "T_team": Team.objects.filter(team_name__startswith="T"),
		# "all_teams_location": Team.objects.order_by('location'),
		# "all_teams_name_reverse": Team.objects.order_by('team_name').reverse(),
		# "last_name_cooper": Player.objects.filter(last_name__contains="Cooper"),
		# "first_name_joshua": Player.objects.filter(first_name__contains="Joshua"),
		# "cooper_no_joshua": Player.objects.filter(last_name__contains="Cooper").exclude(first_name__contains="Joshua"),
		# "alexander_or_wyatt": Player.objects.filter(first_name__contains="Alexander")|Player.objects.filter(first_name__contains="Wyatt"),
		"atlantic_soccer_conf": Team.objects.filter(league = League.objects.filter(name__contains="Atlantic Soccer Conference")),
		"boston_penguins": Player.objects.filter(curr_team = Team.objects.get(team_name = "Penguins", location="Boston")),
		"international_collegiate_baseball": Player.objects.filter(curr_team__league__name = "International Collegiate Baseball Conference"),
		"american_conf_am_football_lopez": Player.objects.filter(curr_team__league__name = "American Conference of Amateur Football", last_name = "Lopez"),
		"all_football_players": Player.objects.filter(all_teams__league__sport = "Football").distinct(),
		"team_curr_sophia": Team.objects.filter(curr_players__first_name = "Sophia"),
		"league_curr_sophia": League.objects.filter(teams__curr_players__first_name="Sophia"),
		"floresbutnoroughriders": Player.objects.filter(last_name = "Flores").exclude(curr_team__team_name="Roughriders"),
		"pastpresent_SamuelEvans": Team.objects.filter(all_players__first_name="Samuel", all_players__last_name="Evans"),
		"playerspastpresentmanitoba": Player.objects.filter(all_teams__team_name = "Tiger-Cats"),
		"formerplayersforvikings": Player.objects.filter(all_teams__team_name = "Vikings", all_teams__location="Wichita").exclude(curr_team__team_name = "Vikings"),
		"teamsjacobgrayplayed": Team.objects.filter(all_players__first_name="Jacob", all_players__last_name="Gray").exclude(team_name = "Colts"),
		"joshuawhoplayedforatlanticfedambb": Player.objects.filter(first_name="Joshua", all_teams__league__name = "Atlantic Federation of Amateur Baseball Players"),
		"teamsmorethan12players": Team.objects.all().annotate(count_all_players = Count('all_players')).filter(count_all_players__gt = 11),
		"sortplayersbynumofteams": Player.objects.all().annotate(count_all_players = Count('all_teams__id')).order_by('-count_all_players')


	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
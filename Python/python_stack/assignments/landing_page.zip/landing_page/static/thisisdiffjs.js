alert("Hello!");

function myF(){
    alert("Hello, I'm a corgi!!");
}

public class Mammal {
	protected int energyLevel;
	
	public Integer displayEnergy() {
		System.out.println("Energy Level "+energyLevel);
		return energyLevel;
	}
	
	
}

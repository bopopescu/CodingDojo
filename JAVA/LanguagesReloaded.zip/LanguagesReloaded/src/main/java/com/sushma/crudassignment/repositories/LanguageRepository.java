package com.sushma.crudassignment.repositories;

import org.springframework.data.repository.CrudRepository;

import com.sushma.crudassignment.models.Language;

public interface LanguageRepository extends CrudRepository<Language, Long>{

}

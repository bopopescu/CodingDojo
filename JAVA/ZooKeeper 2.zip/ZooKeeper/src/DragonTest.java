
public class DragonTest {
	public static void main(String[] args) {
		Dragon eragon = new Dragon();
		eragon.attackTown();
		eragon.attackTown();
		eragon.attackTown();
		eragon.eatHumans();
		eragon.eatHumans();
		eragon.fly();
		eragon.fly();
		
	}

}

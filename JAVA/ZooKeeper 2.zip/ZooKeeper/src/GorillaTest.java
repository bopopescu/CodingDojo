
public class GorillaTest {
	public static void main(String[] args) {
		Gorilla harambe = new Gorilla();
		harambe.throwsomething();
		harambe.throwsomething();
		harambe.throwsomething();
		harambe.eatBananas();
		harambe.eatBananas();
		harambe.climb();
	}
}

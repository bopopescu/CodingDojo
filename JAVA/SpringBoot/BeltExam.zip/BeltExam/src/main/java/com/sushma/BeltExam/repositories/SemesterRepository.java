package com.sushma.BeltExam.repositories;

import org.springframework.data.repository.CrudRepository;

import com.sushma.BeltExam.models.Semester;

public interface SemesterRepository  extends CrudRepository<Semester, Long>{

}

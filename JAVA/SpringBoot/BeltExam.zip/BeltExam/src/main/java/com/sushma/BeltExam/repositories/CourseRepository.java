package com.sushma.BeltExam.repositories;

import org.springframework.data.repository.CrudRepository;

import com.sushma.BeltExam.models.Course;

public interface CourseRepository extends CrudRepository<Course, Long>{

}

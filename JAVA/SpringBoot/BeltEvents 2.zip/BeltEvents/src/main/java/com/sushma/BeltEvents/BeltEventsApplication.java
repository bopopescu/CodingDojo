package com.sushma.BeltEvents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeltEventsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeltEventsApplication.class, args);
	}
}

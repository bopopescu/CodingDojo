package com.sushma.portfolioassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfolioAssignmentApplication.class, args);
	}
}

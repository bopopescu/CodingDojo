package com.sushma.ProductsandCategories;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsandCategoriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductsandCategoriesApplication.class, args);
	}
}

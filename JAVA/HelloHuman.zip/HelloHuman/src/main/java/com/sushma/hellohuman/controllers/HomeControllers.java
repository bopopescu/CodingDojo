package com.sushma.hellohuman.controllers;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//@Controller("/")
@RestController
//@RequestMapping("/hello")
public class HomeControllers {
	   @RequestMapping("/")
	    public String index(@RequestParam(value="name", required=false) String searchQuery) {
		   if(searchQuery == null) {
			   return "Hello Human! Welcome to SpringBoot!";
		   }
		   else {
			   return "Hello " + searchQuery+ "! Welcome to SpringBoot!";
		   }
//		   return "You searched for " + searchQuery;
	   }
		   


}

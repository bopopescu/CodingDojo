package com.sushma.DojosandNinjas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojosandNinjasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojosandNinjasApplication.class, args);
	}
}

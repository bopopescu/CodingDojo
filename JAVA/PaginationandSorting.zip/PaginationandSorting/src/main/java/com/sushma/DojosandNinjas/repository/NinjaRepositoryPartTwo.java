package com.sushma.DojosandNinjas.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.sushma.DojosandNinjas.models.Ninja;

public interface NinjaRepositoryPartTwo extends PagingAndSortingRepository<Ninja, Long>{

}

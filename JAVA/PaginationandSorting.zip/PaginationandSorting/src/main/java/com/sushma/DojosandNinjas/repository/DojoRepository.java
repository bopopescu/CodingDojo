package com.sushma.DojosandNinjas.repository;

import org.springframework.data.repository.CrudRepository;

import com.sushma.DojosandNinjas.models.Dojo;

public interface DojoRepository extends CrudRepository<Dojo, Long>{

}

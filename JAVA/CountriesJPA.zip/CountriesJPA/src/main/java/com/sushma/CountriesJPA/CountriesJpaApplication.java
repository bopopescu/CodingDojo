package com.sushma.CountriesJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CountriesJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CountriesJpaApplication.class, args);
	}
}

package com.sushma.web.models;

public interface Pet  {
	public String showAffection();
}

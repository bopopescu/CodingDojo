package com.sushma.crudassignment;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CrudAssignmentApplicationTests {

	@Test
	public void contextLoads() {
	}

}

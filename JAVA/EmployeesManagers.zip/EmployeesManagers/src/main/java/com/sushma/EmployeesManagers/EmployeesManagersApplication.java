package com.sushma.EmployeesManagers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeesManagersApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeesManagersApplication.class, args);
	}
}

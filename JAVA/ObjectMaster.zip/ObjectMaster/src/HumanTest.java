
public class HumanTest {
	public static void main(String[] args){
		human harry = new human();
		human vold = new human();
		harry.display();
		vold.display();
		harry.attack(vold);
		harry.display();
		vold.display();
	}
}
